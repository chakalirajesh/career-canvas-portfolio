package com.careercanvas.portfolio.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.careercanvas.portfolio.entity.ContactMessage;
import com.careercanvas.portfolio.repository.ContactRepository;

@Service
public class ContactService {

    private final ContactRepository contactRepository;

    public ContactService(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }

    public ContactMessage saveMessage(ContactMessage contactMessage) {
        return contactRepository.save(contactMessage);
    }

    public List<ContactMessage> getAllMessages() {
        return contactRepository.findAll();
    }
}