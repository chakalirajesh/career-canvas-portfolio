package com.careercanvas.portfolio.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;


import com.careercanvas.portfolio.dto.EducationRequest;
import com.careercanvas.portfolio.entity.Education;
import com.careercanvas.portfolio.service.EducationService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/education")
public class EducationController {

    private final EducationService educationService;

    public EducationController(EducationService educationService) {
        this.educationService = educationService;
    }

    @PostMapping
    public Education createEducation(
            @Valid @RequestBody EducationRequest request) {

        Education education = new Education();

        education.setDegree(request.getDegree());
        education.setCollege(request.getCollege());
        education.setBranch(request.getBranch());
        education.setStartYear(request.getStartYear());
        education.setEndYear(request.getEndYear());

        return educationService.saveEducation(education);
    }

    @GetMapping
    public List<Education> getAllEducation() {
        return educationService.getAllEducation();
    }
}